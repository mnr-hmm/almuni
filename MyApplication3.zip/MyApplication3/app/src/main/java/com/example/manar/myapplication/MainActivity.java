package com.example.manar.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main
        );
    }

    public void toCompany(View v){

        Intent i = new Intent(MainActivity.this,company.class);
        startActivity(i);

    }

    public void toNews(View v){

        Intent i = new Intent(MainActivity.this,news.class);
        startActivity(i);

    }

    public void toGradParties(View v){

        Intent i = new Intent(MainActivity.this,news.class);
        startActivity(i);

    }

    public void toTalaqi(View v){

        Intent i = new Intent(MainActivity.this,news.class);
        startActivity(i);

    }

    public void toServices(View v){

        Intent i = new Intent(MainActivity.this,MainServices.class);
        startActivity(i);

    }
}
